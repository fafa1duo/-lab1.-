# ChangeColorType

- Institucional - URI Erechim - Processamento de Imagens
   - Projeto criado referente atividade da primeira aula de Processamento de Imagens;
##

Atividades propostas:
- Normalizar um valor RGB.
- Converter um valor RGB para HSV.
- Converter um valor HSV para RGB.
- Converter um valor RGB para CMYK.
- Converter CMYK para RGB.
- Converter um valor RGB para Escala de Cinza.
